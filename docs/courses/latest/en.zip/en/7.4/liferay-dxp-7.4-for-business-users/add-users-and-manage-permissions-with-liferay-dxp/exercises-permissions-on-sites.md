<a href="#" id="4"></a>

## Manage Teams and Community Permissions 

<div class="ahead">

#### Exercise Goals
* Create a Site Team for the Mondego Publications Site
* Modify Permissions on a Resource on the Site

</div>

#### Go to the Mondego Publications Site
1. **Open** the _Site Menu_.  
* **Click** the _Site Selector_ icon to view available Sites.
* **Click** on the _My Sites_ tab.
	* If you've followed along with the Main and Bonus Exercises from the _Build New Sites with Liferay DXP_ module, you should have seven Sites, five Mondego Sites and two Organization Sites.
* **Click** on the _4 Child Sites_ link.
* **Choose** the _Mondego Publications_ Site.

<br />

#### Create a Web Moderators Site Team
1. **Open** the _Site Menu_
* **Go to** _`People > Teams`_. 
* **Click** the _Add_ icon at the top right.
* **Type** `Web Moderators` for the _Name_.
* **Type** `A team for moderating message boards, blog comments, and community engagement` for the _Description_.
* **Click** _Save_.

<br />

#### Add Ayokunle Idowu to the Mondego Publications Site
1. **Click** _Web Moderators_ to open the new team.
* **Click** the _Add_ icon at the top right.
	- The only available User should be your Administrator. We need to grant Users membership before we can add them to the Web Moderators Team. 
* **Close** the pop-up.
* **Open** the _Control Panel_ in the _Global Menu_.
* **Go to** _`Users > Users and Organizations`_.
* **Click** _Ayokunle Idowu_.
* **Go to** _Memberships_ in the left panel.
* **Click** _Select_ next to _Sites_. 
* **Choose** _Mondego Publications_.
* **Click** _Save_ at the bottom of the page.

<br />

#### Add Ayokunle Idowu to the Web Moderators Site Team
1. **Open** the _Global Menu_.
* **Select** _Mondego Publications_ from the _Sites_ tab. 
* **Open** the _Site Menu_.
* **Go to** _`People > Teams`_. 
* **Click** _Web Moderators_ to open the team.
* **Click** the _Add_ icon at the top right.
* **Check** the box next to _Ayokunle Idowu_.
* **Click** _Add_.

<br />

#### Create a New Community Page
1. **Open** _Site Builder_ in the _Site Administration_ panel.
2. **Click** _Pages_.
3. **Click** _Add_ at the top right.
4. **Choose** _Public Page_.
5. **Click** _Blank_ to add a Content Page.
6. **Type** `Community` for the _Name_.
7. **Click** _Add_.

<br />

#### Add a Message Board Widget to the New Page
1. **Open** the _Fragments and Widgets_ menu (the plus icon) at the right.
2. **Go to** _`Widgets > Collaboration`_.
3. **Drop** a _Message Boards_ widget onto the page.
4. **Click** the _Publish_ button at the top right.
	- You should see two Public Pages: _Blog_ and _Community_. 

<br />

#### Grant the Web Moderator Team Permissions to the Message Board Widget
1. **Click** on the _Community_ page. 
2. **Click** on the _Options_ menu next to the _New Thread_ button.
3. **Click** _Permissions_.
4. **Check** every permission except for _Permissions_ for _Web Moderators_.
5. **Click** _Save_.
6. **Close** the pop-up.

<br />

---

#### Bonus Exercises:
1. Grant Bethany Park and Corrie Alders membership to the Mondego Publications Site. Add them to the Web Moderators Team. Sign out of your administrator account and sign in as either Bethany or Corrie.
2. Create at least one additional User and add them to the Web Moderators Team. Add a new Widget to the Community Page and grant permissions to the team.